import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class praticandoEmSala {

    @Test
    public void shouldReturnStatus200AndTheRequiredFieldsPraticando() {
        given().
                header("Content-Type", "application/json").
                body("{\"query\":\"query {\\n  country(code:\\\"BE\\\")\\n  {\\n    code\\n    name\\n    native\\n    phone\\n    languages\\n    {\\n        code\\n        name\\n    }\\n  }\\n}\",\"variables\":{}}").
                when().
                post("https://countries.trevorblades.com/").
                then().
                assertThat().
                statusCode(200).log().body();
    }
}
