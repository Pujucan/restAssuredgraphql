import io.restassured.response.Response;
import org.testng.annotations.Test;
import java.util.List;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;

public class CountriesQueryTest {

    //Caline
    //Sandrine
    String body="{\"query\":\"\\r\\nquery{\\r\\n  continents(filter:{\\r\\n    code:\\r\\n    {\\r\\n      in:[\\\"AF\\\"]\\r\\n    }\\r\\n    })\\r\\n\\t{\\r\\n    code\\r\\n    }\\r\\n  }\\r\\n\",\"variables\":{}}";
    String variable="{\"query\":\"\\r\\nquery{\\r\\n  continents(filter:{\\r\\n    code:\\r\\n    {\\r\\n      in:[\\\"AF\\\"]\\r\\n    }\\r\\n    })\\r\\n\\t{\\r\\n    code\\r\\n    }\\r\\n  }\\r\\n\",\"variables\":{}}";
    String bodyError="{\"query\":\"\\r\\nquery{\\r\\n  (filter:{\\r\\n    code:\\r\\n    {\\r\\n      in:[\\\"AF\\\"]\\r\\n    }\\r\\n    })\\r\\n\\t{\\r\\n    code\\r\\n    }\\r\\n  }\\r\\n\",\"variables\":{}}";

    //Pujucan
    @Test
    public void validaTipoCampoContinente(){
        Response response= ContinentsRequest.postContinents(body,Constants.BASE_URL);
        response.
                then().
                assertThat().body("data.continents", instanceOf(List.class));
    }

    //Filipe
    @Test
    public void shouldReturnStatus200AndRequiredFields(){
        Response response= ContinentsRequest.postContinents(body,Constants.BASE_URL);
        response.
                then().
                assertThat().statusCode(200).body("data.continents[0].code", equalTo("AF"));
    }

    //Bianka
    @Test
    public void validaErro400(){

        Response response= ContinentsRequest.postContinents(bodyError,Constants.BASE_URL);
        response.
                then().
                assertThat().statusCode(400);
    }
}